import React from 'react';
import { connect } from 'react-redux';
import { addTodo, toggleTodo, deleteTodo } from '../store/actions';
import './main.css';

class TodoList extends React.Component {
  state = {
    text: '',
    editingIndex: null, // To track the index of the item being edited
    filter: 'all', // To track the filter status ('all', 'completed', 'not-completed')
  };

  handleChange = (e) => {
    this.setState({ text: e.target.value });
  };

  handleSubmit = (e) => {
    e.preventDefault();
    if (this.state.text.trim()) {
      if (this.state.editingIndex !== null) {
        // If editingIndex is not null, update the todo at the editingIndex
        this.props.toggleTodo(this.state.editingIndex, this.state.text, true); // Pass true to indicate edit mode
        this.setState({ text: '', editingIndex: null }); // Reset text and editingIndex
      } else {
        this.props.addTodo(this.state.text);
        this.setState({ text: '' });
      }
    }
  };

  handleEdit = (index, text) => {
    // Set the text and editingIndex state to enable editing mode
    this.setState({ text, editingIndex: index });
  };

  handleFilterChange = (filter) => {
    this.setState({ filter });
  };
  

  render() {
    const filteredTodos = this.props.todos.filter(todo => {
      if (this.state.filter === 'completed') {
        return todo.completed;
      } else if (this.state.filter === 'not-completed') {
        return !todo.completed;
      }
      return true; // 'all' filter or default case
    });

    return (
      <div className='container'>
        <h1>Todo List</h1>
        <form onSubmit={this.handleSubmit}>
          <input type="text" value={this.state.text} onChange={this.handleChange} />
          <button type="submit">{this.state.editingIndex !== null ? 'Save Edit' : 'Add Todo'}</button>
        </form>
        <div>
          <label>
            <input
              type="radio"
              value="all"
              checked={this.state.filter === 'all'}
              onChange={() => this.handleFilterChange('all')}
            />
            All
          </label>
          <label>
            <input
              type="radio"
              value="completed"
              checked={this.state.filter === 'completed'}
              onChange={() => this.handleFilterChange('completed')}
            />
            Completed
          </label>
          <label>
            <input
              type="radio"
              value="not-completed"
              checked={this.state.filter === 'not-completed'}
              onChange={() => this.handleFilterChange('not-completed')}
            />
            Not Completed
          </label>
        </div>
        <ul>
          {filteredTodos.map((todo, index) => (
            <li key={todo.id}>
              <span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>{todo.text}</span>
              <button onClick={() => this.props.toggleTodo(index)}>{todo.completed ? 'Undone' : 'Done'}</button>
              {!todo.completed && !this.state.editingIndex && (
                <button onClick={() => this.handleEdit(index, todo.text)}>Edit</button>
              )}
              {todo.completed && (
                <button onClick={() => this.props.deleteTodo(todo.id)}>Delete</button>
              )}
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  todos: state.todos.todos,
});

const mapDispatchToProps = {
  addTodo,
  toggleTodo,
  deleteTodo,
};

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
