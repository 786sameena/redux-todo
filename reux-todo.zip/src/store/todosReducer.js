import { ADD_TODO, TOGGLE_TODO, DELETE_TODO } from './actions';

const initialState = {
  todos: [],
};

const todosReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TODO:
      return {
        ...state,
        todos: [...state.todos, { id: Date.now(), text: action.payload, completed: false }],
      };
     // In reducers.js

case TOGGLE_TODO:
    const { index, text, editMode } = action.payload;
    if (editMode) {
      return {
        ...state,
        todos: state.todos.map((todo, i) =>
          i === index ? { ...todo, text } : todo
        ),
      };
    } else {
      return {
        ...state,
        todos: state.todos.map((todo, i) =>
          i === index ? { ...todo, completed: !todo.completed } : todo
        ),
      };
    }
  
    case DELETE_TODO:
      return {
        ...state,
        todos: state.todos.filter(todo => todo.id !== action.payload),
      };
    default:
      return state;
  }
};

export default todosReducer;
